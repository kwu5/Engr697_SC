package com.example.smartscale;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FirebaseUIActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebase_ui);
    }
}
